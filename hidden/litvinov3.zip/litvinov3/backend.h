#ifndef BACKEND_H
#define BACKEND_H
#include "codegenerator.h"

class BackEnd : public QObject {
  Q_OBJECT
  Q_PROPERTY(QString Code READ Code WRITE setCode NOTIFY CodeChanged)
  Q_PROPERTY(
      float BarState READ BarState WRITE setBarState NOTIFY BarStateChanged)
  Q_PROPERTY(QString ResultText READ ResultText WRITE setResultText NOTIFY
                 ResultTextChanged)
public:
  explicit BackEnd() {

    generator = new CodeGenerator(6, 10);
    generator_thread = new QThread();
    generator->moveToThread(generator_thread);

    QObject::connect(generator, &CodeGenerator::codeCreated, this,
                     &BackEnd::setCode);
    QObject::connect(generator, &CodeGenerator::tickProcessed, this,
                     &BackEnd::setBarState);

    generator_thread->start();
    generator->createCode();
    current_bar_state = 1;
    result_text = "WRONG CODE";
  }
  Q_INVOKABLE void checkCodes(const QString &input_code) {
    if (input_code == current_code) {
      result_text = "SUCCESS";
    } else {
      result_text = "WRONG CODE";
    }
    emit ResultTextChanged();
  }
  ~BackEnd() {
      generator_thread->quit();
      delete generator;
  }

  QString Code() { return current_code; }
  float BarState() { return current_bar_state; }
  QString ResultText() { return result_text; }

signals:
  void CodeChanged();
  void BarStateChanged();
  void ResultTextChanged();
public slots:
  void setCode(const QString &new_code) {
    if (current_code != new_code) {
      current_code = new_code;
      emit CodeChanged();
    }
  }
  void setBarState(const float &new_bar_state) {
    if (current_bar_state != new_bar_state) {
      current_bar_state = new_bar_state;
      emit BarStateChanged();
    }
  }
  void setResultText(const QString &text) {
    result_text = text;
    emit ResultTextChanged();
  }

private:
  QString current_code;
  float current_bar_state;
  QString input_code;
  QString result_text;
  CodeGenerator *generator;
  QThread *generator_thread;
};

#endif // BACKEND_H
