import QtQuick 2.15
import QtQuick.Window 2.15
import QtQuick.Controls 2.15
import QtQuick.Dialogs 1.3
import Slava 1.0
Window {
    id: win
    width: 640
    height: 480
    visible: true
    title: qsTr("code generator")

    BackEnd{
        id : backEnd
    }

    Rectangle {
        id: textRect
        anchors.centerIn: parent
        width: 100
        height: 30
        border.width: 1
        border.color: "black"
        TextInput {
            id: textInput
            anchors.fill: parent
            font.pointSize: 15
            clip: true
        }
    }
    Button {
        id: enterButton
        text: qsTr("Enter")
        anchors.top: textRect.bottom
        anchors.topMargin: 15
        anchors.horizontalCenter: parent.horizontalCenter
        onClicked: {
            backEnd.checkCodes(textInput.text)
            messageDialog.visible = true
        }
    }
    ProgressBar {
        id: progressBar
        value: backEnd.BarState
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 10
        anchors.horizontalCenter: parent.horizontalCenter

    }
    Text {
        id: textCode
        font.pointSize: 20
        text: backEnd.Code
        anchors.bottom: progressBar.top
        anchors.bottomMargin: 10
        anchors.horizontalCenter: parent.horizontalCenter

    }
    MessageDialog {
        id: messageDialog
        title: "Result"
        text: backEnd.ResultText
        onAccepted: {
            visible = false
        }
        visible: false
    }
}
