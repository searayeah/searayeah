#ifndef CODEGENERATOR_H
#define CODEGENERATOR_H
#include <QObject>
#include <QRandomGenerator>
#include <QString>
#include <QThread>
#include <QTimer>

class CodeGenerator : public QObject {
  Q_OBJECT
public:
  explicit CodeGenerator(int code_length_ = 6, int code_time_ = 10) {

    possible_characters =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    code_length = code_length_;
    code_time = code_time_;
    current_tick = 1;

    code_timer = new QTimer();
    tick_timer = new QTimer();

    connect(code_timer, SIGNAL(timeout()), this, SLOT(createCode()));
    connect(tick_timer, SIGNAL(timeout()), this, SLOT(processTick()));

    code_timer->start(code_time * 1000);
    tick_timer->start(1000);
  }

public slots:
  void createCode() {
    QString result;
    for (int i = 0; i < code_length; ++i) {
      int index =
          QRandomGenerator::global()->bounded(0, possible_characters.size());
      QChar nextChar = possible_characters.at(index);
      result.append(nextChar);
    }

    emit codeCreated(result);
  }
  void processTick() {
    if (current_tick >= 1e-5) {
      current_tick = current_tick - (1.0 / (code_time - 1));
    } else {
      current_tick = 1;
    }
    emit tickProcessed(current_tick);
  }

signals:
  void codeCreated(const QString &result);
  void tickProcessed(const float &curr_tick);

private:
  QTimer *code_timer;
  QTimer *tick_timer;
  float current_tick;
  int code_length;
  int code_time;
  QString possible_characters;
};

#endif // CODEGENERATOR_H
