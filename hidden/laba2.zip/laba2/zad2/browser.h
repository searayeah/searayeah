#ifndef BROWSER_H
#define BROWSER_H
#include <QErrorMessage>
#include <QTextBrowser>

class Browser {
private:
  QTextBrowser *textbrowser;
  QStringList banwords;

public:
  Browser(QWidget *parent) {
    textbrowser = new QTextBrowser(parent);
    textbrowser->setFixedSize(480, 400);
    textbrowser->move(10, 10);

    banwords << "apple"
             << "banana"
             << "lemon";
  }

  void append(const QString &string) {
    if (!banwords.contains(string)) {
      textbrowser->append(string);
    } else {
      QErrorMessage errormsg = QErrorMessage();
      errormsg.showMessage("THIS WORD IS NOT ALLOWED");
      errormsg.exec();
    }
  }
};

#endif // BROWSER_H
