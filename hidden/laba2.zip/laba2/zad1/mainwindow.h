#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "WindowBuilder.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_errorButton_clicked();

    void on_textInputButton_clicked();

    void on_confirmButton_clicked();

    void on_filesButton_clicked();

private:
    Ui::MainWindow *ui;
    ErrorWindowBuilder error_window_builder;
    TextInputWindowBuilder text_input_window_builder;
    ConfirmWindowBuilder confirm_window_builder;
    FilesWindowBuilder files_window_builder;
    Director director;
};
#endif // MAINWINDOW_H
