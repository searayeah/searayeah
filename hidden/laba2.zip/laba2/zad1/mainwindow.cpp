#include "mainwindow.h"
#include "WindowBuilder.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
  ui->setupUi(this);
}

MainWindow::~MainWindow() { delete ui; }

void MainWindow::on_errorButton_clicked() {
  error_window_builder = ErrorWindowBuilder();
  director.setupWindow(&error_window_builder);
  error_window_builder.getWindow()->show();
}

void MainWindow::on_textInputButton_clicked() {
  text_input_window_builder = TextInputWindowBuilder();
  director.setupWindow(&text_input_window_builder);
  text_input_window_builder.getWindow()->show();
}

void MainWindow::on_confirmButton_clicked() {
  confirm_window_builder = ConfirmWindowBuilder();
  director.setupWindow(&confirm_window_builder);
  confirm_window_builder.getWindow()->show();
}

void MainWindow::on_filesButton_clicked() {
  files_window_builder = FilesWindowBuilder();
  director.setupWindow(&files_window_builder);
  files_window_builder.getWindow()->show();
}
