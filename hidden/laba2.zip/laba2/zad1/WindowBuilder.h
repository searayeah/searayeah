#ifndef WINDOWBUILDER_H
#define WINDOWBUILDER_H
#include <QComboBox>
#include <QDialog>
#include <QErrorMessage>
#include <QFileSystemModel>
#include <QLabel>
#include <QLineEdit>
#include <QObject>
#include <QPushButton>
#include <QTextEdit>
#include <QToolBar>
#include <QTreeView>
#include <QWidget>
#include <QtGlobal>

class WindowBuilder {
public:
  virtual ~WindowBuilder() {}
  virtual void setWindowAppearance() {}
  virtual void setWindowElements() {}
  virtual QWidget *getWindow() { return window; };

protected:
  QWidget *window;
};

class Director {
public:
  void setupWindow(WindowBuilder *window_builder) {
    window_builder->setWindowAppearance();
    window_builder->setWindowElements();
  }
};

class ErrorWindowBuilder : public WindowBuilder {
public:
  ~ErrorWindowBuilder() override { delete window; }
  void setWindowAppearance() override {
    window = new QWidget();
    window->setFixedSize(300, 150);
    window->setWindowTitle("ErrorWindowBuilder");
  }
  void setWindowElements() override {
    QPushButton *button = new QPushButton(window);
    button->move(200, 100);
    button->setText("EXIT");

    QLabel *label = new QLabel(window);
    label->move(75, 35);
    label->setText("THIS IS ERROR MESSAGE");

    QAbstractButton::connect(button, &QPushButton::clicked, window,
                             &QWidget::close);
  }
};

class TextInputWindowBuilder : public WindowBuilder {
public:
  ~TextInputWindowBuilder() override { delete window; }
  void setWindowAppearance() override {
    window = new QWidget();
    window->setWindowTitle("TextInputWindowBuilder");
    window->setFixedSize(300, 300);
  }
  void setWindowElements() override {
    QToolBar *toolbar = new QToolBar(window);
    toolbar->addAction("FILE");
    toolbar->addAction("EDIT");
    toolbar->addAction("VIEW");
    toolbar->addAction("HELP");

    QTextEdit *text_edit = new QTextEdit(window);
    text_edit->move(10, 40);
    text_edit->setFixedSize(280, 200);

    QPushButton *button_1 = new QPushButton(window);
    button_1->move(10, 250);
    button_1->setText("CANCEL");

    QPushButton *button_2 = new QPushButton(window);
    button_2->move(205, 250);
    button_2->setText("OK");

    QAbstractButton::connect(button_1, &QPushButton::clicked, window,
                             &QWidget::close);
  }
};

class ConfirmWindowBuilder : public WindowBuilder {
public:
  ~ConfirmWindowBuilder() override { delete window; }
  void setWindowAppearance() override {
    window = new QWidget();
    window->setFixedSize(300, 150);
    window->setWindowTitle("ConfirmWindowBuilder");
  }
  void setWindowElements() override {
    QPushButton *button_1 = new QPushButton(window);
    button_1->move(10, 100);
    button_1->setText("CANCEL");

    QPushButton *button_2 = new QPushButton(window);
    button_2->move(205, 100);
    button_2->setText("OK");

    QLabel *label = new QLabel(window);
    label->move(70, 35);
    label->setText("DO YOU WANT TO PROCEED??");

    QAbstractButton::connect(button_1, &QPushButton::clicked, window,
                             &QWidget::close);
  }
};

class FilesWindowBuilder : public WindowBuilder {
public:
  ~FilesWindowBuilder() override { delete window; }
  void setWindowAppearance() override {
    window = new QWidget();
    window->setFixedSize(500, 460);
    window->setWindowTitle("FilesWindowBuilder");
  }
  void setWindowElements() override {

    QFileSystemModel *model = new QFileSystemModel(window);
    model->setRootPath(QDir::currentPath());
    model->setNameFilterDisables(false);

    QTreeView *tree = new QTreeView(window);
    tree->setModel(model);
    tree->move(10, 10);
    tree->setFixedSize(480, 400);

    QComboBox *combobox = new QComboBox(window);
    combobox->move(330, 420);
    combobox->addItem("");
    combobox->addItem("*.txt");
    combobox->addItem("*.pdf");
    combobox->addItem("*.html");

    QLineEdit *lineedit = new QLineEdit(window);
    lineedit->move(100, 420);
    lineedit->setFixedWidth(230);

    QPushButton *button_1 = new QPushButton(window);
    button_1->move(410, 420);
    button_1->setText("OPEN");

    QPushButton *button_2 = new QPushButton(window);
    button_2->move(10, 420);
    button_2->setText("CANCEL");

    QAbstractButton::connect(button_2, &QPushButton::clicked, window,
                             &QWidget::close);

    QObject::connect(tree, &QTreeView::clicked, [=](const QModelIndex &index) {
      lineedit->setText(model->filePath(index));
    });
    QObject::connect(combobox, qOverload<int>(&QComboBox::currentIndexChanged),
                     [=](int index) {
                       QStringList filters;
                       filters.append(combobox->itemText(index));
                       model->setNameFilters(filters);
                     });
  }
};

#endif // WINDOWBUILDER_H
