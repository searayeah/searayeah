#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTextStream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    this->originator = new Originator(ui->tableWidget);
    this->caretaker = new CareTaker();
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_2_clicked()
{
    int i = this->caretaker->append(this->originator->saveToMemento());
    ui->listWidget->addItem(QString::number(i));
}


void MainWindow::on_pushButton_clicked()
{
    int i = ui->listWidget->item(ui->listWidget->currentRow())->text().toInt();
    this->originator->restoreFromMemento(this->caretaker->get(i));
}

