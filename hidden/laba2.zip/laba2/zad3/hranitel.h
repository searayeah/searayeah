#ifndef HRANITEL_H
#define HRANITEL_H

#include <QDebug>
#include <QString>
#include <QTableWidget>
#include <QVector>

class Memento {
public:
  Memento(QVector<QVector<QString>> state_to_save) { state = state_to_save; }
  QVector<QVector<QString>> getState() { return state; }
  QVector<QVector<QString>> state;
};

class Originator {

private:
  QTableWidget *table;

public:
  Originator(QTableWidget *table_input) {
    table = table_input;
    table->setRowCount(3);
    table->setColumnCount(3);
    for (int i = 0; i < table->rowCount(); ++i) {
      for (int j = 0; j < table->columnCount(); ++j) {
        QTableWidgetItem *new_item =
            new QTableWidgetItem(QString::number(i + j));
        table->setItem(i, j, new_item);
      }
    }
  }

  Memento saveToMemento() {
    QVector<QVector<QString>> new_state;
    for (int i = 0; i < table->rowCount(); ++i) {
      new_state.append(QVector<QString>());
      for (int j = 0; j < table->columnCount(); ++j) {
        QString new_item = QString(table->item(i, j)->text());
        new_state[i].append(new_item);
      }
    }
    return Memento(new_state);
  }

  void restoreFromMemento(Memento memento) {
    QVector<QVector<QString>> new_state = memento.getState();
    for (int i = 0; i < table->rowCount(); ++i) {
      for (int j = 0; j < table->columnCount(); ++j) {
        QTableWidgetItem *new_item = new QTableWidgetItem(new_state[i][j]);
        table->setItem(i, j, new_item);
      }
    }
  }
};

class CareTaker {
public:
  int append(Memento input) {
    states.append(input);
    return states.size() - 1;
  }
  Memento get(int number) { return states[number]; }

private:
  QVector<Memento> states;
};

#endif // HRANITEL_H
